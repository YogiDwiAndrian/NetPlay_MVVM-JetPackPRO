package com.kajangdevs.netplay

import com.kajangdevs.netplay.data.source.local.entity.MovieDetailEntity
import com.kajangdevs.netplay.data.source.local.entity.MovieEntity
import com.kajangdevs.netplay.data.source.local.entity.TvShowDetailEntity
import com.kajangdevs.netplay.data.source.local.entity.TvShowEntity

object DataDummy {

    fun testDetailMovie(): List<MovieDetailEntity> {
        return listOf(
            MovieDetailEntity(
                0,
                "Dicoding Test",
                "2020",
                "1 min",
                0.0f,
                "",
                "",
                "",
                "",
                "",
                "",
                ""
            )
        )
    }

    fun testDetailTvSHow(): List<TvShowDetailEntity> {
        return listOf(
            TvShowDetailEntity(
                0,
                "Dicoding Test",
                "2020",
                "1 min",
                0.0f,
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                ""
            )
        )
    }

    fun testMovie(): List<MovieEntity> {
        return listOf(
            MovieEntity(
                0,
                "Dicoding Test",
                0.0f,
                "1 min",
                "",
                listOf()
            )
        )
    }

    fun testTvShow(): List<TvShowEntity> {
        return listOf(
            TvShowEntity(
                0,
                "Dicoding Test",
                0.0f,
                "1 min",
                "",
                listOf()
            )
        )
    }

}