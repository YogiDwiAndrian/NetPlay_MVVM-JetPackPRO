package com.kajangdevs.netplay.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kajangdevs.netplay.data.DataSource
import com.kajangdevs.netplay.data.source.local.entity.MovieDetailEntity
import com.kajangdevs.netplay.data.source.local.entity.TvShowDetailEntity
import com.kajangdevs.netplay.utils.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DetailViewModel(private val dataSource: DataSource) : ViewModel() {

    private var _movie = MutableLiveData<Resource<MovieDetailEntity>>()
    val movie: LiveData<Resource<MovieDetailEntity>> = _movie
    private var _tvShow = MutableLiveData<Resource<TvShowDetailEntity>>()
    val tvShow: LiveData<Resource<TvShowDetailEntity>> = _tvShow


        fun getTvShow(id: Int) {
            _tvShow.postValue(Resource.Loading)
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    _tvShow.postValue(Resource.Success(dataSource.fetchTvShowDetailById(id)))
                } catch (t: Throwable) {
                    _tvShow.postValue(Resource.Failure(t))
                }
            }
    }

    fun getMovie(id: Int) {
        _movie.postValue(Resource.Loading)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _movie.postValue(Resource.Success(dataSource.fetchMovieDetailById(id)))
            } catch (t: Throwable) {
                _movie.postValue(Resource.Failure(t))
            }
        }
    }
}