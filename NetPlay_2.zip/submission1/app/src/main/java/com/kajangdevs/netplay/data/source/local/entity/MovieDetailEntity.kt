package com.kajangdevs.netplay.data.source.local.entity

data class MovieDetailEntity(
    val movieId: Int,
    val title: String,
    val released: String,
    val runtime: String,
    val rating: Float,
    val poster: String,
    val backdrop: String,
    val voteCount: String,
    val revenue: String,
    val budget: String,
    val synopsis: String,
    val production: String
)