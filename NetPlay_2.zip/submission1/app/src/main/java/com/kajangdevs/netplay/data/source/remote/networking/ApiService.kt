package com.kajangdevs.netplay.data.source.remote.networking

import com.kajangdevs.netplay.data.source.remote.response.MovieDetailResponse
import com.kajangdevs.netplay.data.source.remote.response.MovieResponse
import com.kajangdevs.netplay.data.source.remote.response.TvShowDetailResponse
import com.kajangdevs.netplay.data.source.remote.response.TvShowResponse
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {

    @GET("movie/{id}")
    suspend fun getMovieDetail(
        @Path("id") id: Int
    ): MovieDetailResponse

    @GET("tv/{id}")
    suspend fun getTvShowDetail(
        @Path("id") id: Int
    ): TvShowDetailResponse

    @GET("movie/now_playing")
    suspend fun getMovies(): MovieResponse

    @GET("tv/popular")
    suspend fun getTvShow(): TvShowResponse
}