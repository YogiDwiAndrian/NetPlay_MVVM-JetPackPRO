package com.kajangdevs.netplay.data

import com.kajangdevs.netplay.data.source.local.entity.MovieDetailEntity
import com.kajangdevs.netplay.data.source.local.entity.MovieEntity
import com.kajangdevs.netplay.data.source.local.entity.TvShowDetailEntity
import com.kajangdevs.netplay.data.source.local.entity.TvShowEntity

interface DataSource {

    suspend fun fetchMovies(): List<MovieEntity>
    suspend fun fetchTvShow(): List<TvShowEntity>
    suspend fun fetchMovieDetailById(id: Int): MovieDetailEntity
    suspend fun fetchTvShowDetailById(id: Int): TvShowDetailEntity
}