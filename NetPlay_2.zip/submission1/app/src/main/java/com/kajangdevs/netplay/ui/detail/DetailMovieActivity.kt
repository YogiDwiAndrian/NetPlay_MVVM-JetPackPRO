package com.kajangdevs.netplay.ui.detail

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.kajangdevs.netplay.R
import com.kajangdevs.netplay.data.source.local.entity.MovieDetailEntity
import com.kajangdevs.netplay.data.source.local.entity.MovieEntity
import com.kajangdevs.netplay.utils.Constant.getGenreNameMv
import com.kajangdevs.netplay.utils.Resource
import com.kajangdevs.netplay.utils.checkNull
import com.kajangdevs.netplay.utils.gone
import com.kajangdevs.netplay.utils.visible
import jp.wasabeef.glide.transformations.BlurTransformation
import kotlinx.android.synthetic.main.activity_detail_movie.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class DetailMovieActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIES = "extra_movies"
    }

    private val detailViewModel: DetailViewModel by viewModel()
    private var genre: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_movie)

        val item: MovieEntity = intent.getParcelableExtra(EXTRA_MOVIES)!!
        genre = getGenreNameMv(item.genreId)!!

        val extras = intent.extras
        if (extras != null) {
            val movieId = item.movieId
            detailViewModel.movie.observe(this, ::updateUI)
            detailViewModel.getMovie(movieId)
        }
    }

    private fun updateUI(resource: Resource<MovieDetailEntity>) {
        when (resource) {
            is Resource.Loading -> {
                ld_detailMv.visible()
            }
            is Resource.Success -> {
                populateMovie(resource.data)
                ld_detailMv.gone()
            }
            is Resource.Failure -> {
            }
        }
    }

    private fun populateMovie(movieEntity: MovieDetailEntity) {
        //binding item to ui
        Glide.with(this)
            .load(movieEntity.backdrop)
            .apply(
                RequestOptions.bitmapTransform(BlurTransformation(20, 3))
                    .placeholder(R.drawable.ic_loading)
                    .error(R.drawable.ic_error)
            )
            .into(img_backdrop)


        Glide.with(this)
            .load(movieEntity.poster)
            .apply(
                RequestOptions.placeholderOf(R.drawable.ic_loading)
                    .error(R.drawable.ic_error)
            )
            .into(img_poster)

        tv_tittle.text = movieEntity.title
        tv_release_year.text = movieEntity.released
        tv_runtime.text = movieEntity.runtime
        tv_revenue.text = movieEntity.revenue
        tv_rating.text = movieEntity.rating.toString()
        tv_count.text = movieEntity.voteCount
        tv_synopsis.text = movieEntity.synopsis
        tv_budget.text = movieEntity.budget
        tv_genre.text = genre.checkNull()
        tv_countries.text = movieEntity.production.checkNull()
    }
}