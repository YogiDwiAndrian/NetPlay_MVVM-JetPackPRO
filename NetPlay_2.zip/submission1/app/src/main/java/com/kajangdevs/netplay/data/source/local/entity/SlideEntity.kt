package com.kajangdevs.netplay.data.source.local.entity

data class SlideEntity(
    val image: Int
)