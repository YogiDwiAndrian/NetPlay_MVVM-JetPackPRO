package com.kajangdevs.netplay.data.source.local.entity

data class HastagEntitiy(
    val image: Int,
    val hastag: String
)